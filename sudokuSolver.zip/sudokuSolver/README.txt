
SUDOKU SOLVER
------------
Autor: Pola Dudek
Krakow 2024
------------

Program sluzy do roziwazywania poprawnie wprowadzonych plansz Sudoku. Czesciowo wypelniona plansza powinna zostac wprowadzona przez uzytkownika za pomoca zaznaczenia mysza danej komorki a nastepnie wprowadzeni
-----------  Najwazniejsze elementy projektu:

Program podzielony jest na 3 moduly: SudokuGrid, Buttons oraz SudokuApp.

- SudokuGrid - zawiera abstrakcyjna klase bazowa SudokuGrid po ktorej dziedziczy klasa pochodna SudokuFinished, ktora ma kolejno dwie klasy pochodne BacktrackingSolver oraz RandomFillSolver. Klasa SudokuGrid zapewnia implementacje planszy sudoku natomiast SudokuFinished odpowiada za jej wypelniona wersje. Metoda solve() odpowiadajaca za wypelnianie planszy klasy SudokuGrid jest metoda czyto wirtualna ktora nadpisana zostaje w klasach BacktrackingSolver oraz RandomFillSolver, uzywajacych do jej implementacji dwoch roznych algorytmow. W faktycznie przedstawionym dla uzytkownika programie do uzytku jest jedynie algorytm zaimplementowany w klasie BacktrackingSolver, w zwiazku ze 100% poprawnoscia zwracanych przez niego plansz, natomiast sama implementacja RandomFillSolver ma na celu lepsze ukazanie pojecia polimorfizmu. 

- Buttons - zawiera klase bazowa Buttons posiadajaca dwa rozne konstruktory oraz dwie klasy pochodne TextButton oraz ImageButton, gdzie uzywaja one po jednym z tych konstruktorow.

- SudokuApp - odpowiada za GUI; przede wszystkim napisana uzywajac funkcji bibliotecznych biblioteki SFML.


---------- Uruchomienie programow:

W celu kompilacji oraz uruchomienia programu nalezy uzyc pliku CMake. Z poziomu powloki nalezy otworzyc folder SudokuSolver a nastepnie otworzyc folder build i uzyc komenty "make". Skompilowany program uruchomic mozna wywolujac z poziomu powloki "./sudoku".

