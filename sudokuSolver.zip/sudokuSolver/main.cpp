#include "SudokuApp.h"

int main()
{
    SudokuApp app;
    app.run();
    return 0;
}
